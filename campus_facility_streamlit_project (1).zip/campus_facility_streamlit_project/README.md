# Campus Facility Reservation and Monitoring System

A Streamlit decision-support app based on the midterm Data Mining and Systems Analysis notebook.

## Pages
- Home
- Dataset (CSV upload, schema validation, preview, missing-value summary)
- Data Analysis (three interactive charts)
- Prediction (new reservation prediction using the saved pipeline)
- Dashboard (observed KPIs and estimated-risk review queue)
- System Design (requirements, actors, use case diagram, workflow)

## Run locally
1. Install Python 3.10 or later.
2. Open a terminal in this project folder.
3. Install dependencies: `pip install -r requirements.txt`
4. Run: `streamlit run app.py`

## Model and evaluation
The saved model is a preprocessing + Decision Tree pipeline using the same eight predictor columns and target as the midterm notebook. The train/test split uses 80/20, random_state=42, stratify=y.

- Cleaned rows: 400
- Training rows: 320
- Test rows: 80
- Accuracy on this rebuild: 57.50%
- Precision for Not Completed: 31.25%
- Recall for Not Completed: 45.45%
- F1-score for Not Completed: 37.04%

**Important:** The evaluation is a preliminary estimate. A prediction must not automatically approve or reject a reservation. An authorized administrator must review it.

## Files
- `app.py` — Streamlit app
- `modules/` — data processing, EDA, prediction and dashboard helpers
- `models/trained_model.joblib` — saved fitted preprocessing/model pipeline
- `data/facility_reservations_clean.csv` — cleaned data from the uploaded midterm workbook
- `data/facility_reservations_original.csv` — original data export
- `assets/use_case_diagram.png` — system use case diagram

Use only synthetic or properly authorized data for public deployment.
