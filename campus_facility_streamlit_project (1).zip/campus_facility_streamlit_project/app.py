import streamlit as st
import pandas as pd
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from modules.data_processing import validate_dataframe, prepare_dataframe, PREDICTOR_COLUMNS
from modules.exploratory_analysis import charts, outcome_counts
from modules.prediction import load_model, predict_one
from modules.dashboard import summarize

st.set_page_config(page_title="Campus Facility Reservation Monitoring", page_icon="🏫", layout="wide")

@st.cache_resource
def get_model():
    return load_model()

@st.cache_data
def get_default_data():
    return pd.read_csv(ROOT / "data" / "facility_reservations_clean.csv")

model = get_model()
menu = st.sidebar.selectbox("Navigate", [
    "Home", "Dataset", "Data Analysis", "Prediction", "Dashboard", "System Design"
])

st.sidebar.caption("Campus Facility Reservation and Monitoring System")
st.sidebar.caption("Predictions are decision-support only.")

if menu == "Home":
    st.title("Campus Facility Reservation and Monitoring System")
    st.subheader("Data Mining and Decision Support")
    st.write("This application summarizes historical campus facility reservations and estimates whether a new reservation may be completed.")
    df = get_default_data()
    c1, c2, c3 = st.columns(3)
    c1.metric("Cleaned records", f"{len(df):,}")
    c2.metric("Facility types", str(df["Facility_Type"].nunique()))
    c3.metric("Outcome classes", str(df["Reservation_Outcome"].nunique()))
    st.info("A prediction is not a final decision. An authorized facility administrator should review the booking details and make the final decision.")
    st.markdown("**Pages:** Dataset validation · Exploratory analysis · Prediction · Decision-support dashboard · System design")

elif menu == "Dataset":
    st.title("Dataset Upload and Validation")
    st.write("Upload a CSV that uses the same columns as the midterm reservation dataset. The included cleaned dataset is used when no file is uploaded.")
    uploaded = st.file_uploader("Upload reservation dataset (CSV)", type=["csv"])
    try:
        if uploaded is not None:
            data = pd.read_csv(uploaded)
            valid, message = validate_dataframe(data)
            if not valid:
                st.error(message)
                st.stop()
            data = prepare_dataframe(data)
            st.success(message)
        else:
            data = get_default_data()
            st.caption("Showing the bundled cleaned midterm dataset.")
        c1, c2, c3 = st.columns(3)
        c1.metric("Rows", len(data))
        c2.metric("Columns", len(data.columns))
        c3.metric("Exact duplicate rows", int(data.duplicated().sum()))
        st.subheader("Preview")
        st.dataframe(data.head(20), use_container_width=True)
        st.subheader("Missing values by column")
        st.dataframe(data.isna().sum().rename("Missing Values").to_frame(), use_container_width=True)
        st.subheader("Descriptive statistics")
        st.dataframe(data.describe(include="all").transpose(), use_container_width=True)
    except Exception as e:
        st.error(f"Could not read this file as a valid reservation CSV: {e}")

elif menu == "Data Analysis":
    st.title("Exploratory Data Analysis")
    df = get_default_data()
    c1, c2, c3 = st.columns(3)
    c1.metric("Reservations", len(df))
    c2.metric("Completed", int((df["Reservation_Outcome"] == "Completed").sum()))
    c3.metric("Not Completed", int((df["Reservation_Outcome"] == "Not Completed").sum()))
    st.subheader("Outcome distribution")
    st.dataframe(outcome_counts(df), use_container_width=True)
    chart1, chart2, chart3, user_summary = charts(df)
    st.plotly_chart(chart1, use_container_width=True)
    st.plotly_chart(chart2, use_container_width=True)
    st.plotly_chart(chart3, use_container_width=True)
    st.caption("These charts describe observed historical data. Associations do not establish cause.")

elif menu == "Prediction":
    st.title("Predictive Modeling")
    st.write("Enter booking details available at reservation submission time. Fields match the midterm model's eight predictors.")
    with st.form("prediction_form"):
        a, b = st.columns(2)
        facility = a.selectbox("Facility Type", ["Classroom", "Laboratory", "Auditorium", "Meeting Room", "Sports Facility"])
        user = b.selectbox("User Category", ["Student Organization", "Faculty", "Administrative Staff", "Student"])
        purpose = a.selectbox("Reservation Purpose", ["Meeting", "Class Activity", "Seminar", "Workshop", "Practice", "Event"])
        lead = b.number_input("Lead Time (days)", min_value=0, max_value=365, value=7)
        duration = a.number_input("Reservation Duration (hours)", min_value=1, max_value=24, value=2)
        participants = b.number_input("Expected Participants", min_value=1, max_value=500, value=25)
        day = a.selectbox("Day of Week (numeric code used in midterm)", list(range(7)), index=2)
        hour = b.slider("Start Hour", min_value=0, max_value=23, value=10)
        submitted = st.form_submit_button("Predict Reservation Outcome")
    if submitted:
        values = {
            "Facility_Type": facility, "User_Category": user, "Reservation_Purpose": purpose,
            "Lead_Time_Days": lead, "Reservation_Duration_Hours": duration,
            "Participants": participants, "Day_of_Week": day, "Start_Hour": hour
        }
        label, risk = predict_one(model, values)
        st.subheader("Model result")
        st.metric("Predicted outcome", label)
        if risk is not None:
            st.metric("Estimated probability of Not Completed", f"{risk*100:.1f}%")
        st.warning("This is an estimate from a model with modest midterm test performance. It must not be used to automatically reject a reservation.")
        st.write("Recommended follow-up: review the booking details and, when appropriate, confirm the reservation with the requester.")

elif menu == "Dashboard":
    st.title("Facility Administrator Decision-Support Dashboard")
    df = get_default_data()
    result = summarize(df, model)
    total = len(result)
    completed = int((result["Reservation_Outcome"] == "Completed").sum())
    not_completed = int((result["Reservation_Outcome"] == "Not Completed").sum())
    avg_risk = result["Predicted_Not_Completed_Probability"].mean()
    a, b, c, d = st.columns(4)
    a.metric("Reservations", total)
    b.metric("Observed Completed", completed)
    c.metric("Observed Not Completed", not_completed)
    d.metric("Average model-estimated risk", f"{avg_risk:.1f}%" if pd.notna(avg_risk) else "N/A")
    st.caption("Observed outcomes are historical facts; predicted outcomes and probabilities are model estimates.")
    st.subheader("Review queue (highest estimated risk)")
    queue = result.sort_values("Predicted_Not_Completed_Probability", ascending=False)
    show_cols = ["Reservation_ID", "Facility_Type", "User_Category", "Lead_Time_Days", "Predicted_Outcome", "Predicted_Not_Completed_Probability", "Reservation_Outcome"]
    st.dataframe(queue[show_cols].head(20).round(2), use_container_width=True)
    st.download_button("Download review queue CSV", queue[show_cols].to_csv(index=False), "reservation_review_queue.csv", "text/csv")
    st.info("Human follow-up is recommended for review; a high estimated risk is not a reason to automatically deny service.")

elif menu == "System Design":
    st.title("Systems Analysis and Design")
    st.subheader("Actors")
    st.markdown("""- **Facility Administrator:** reviews historical statistics, risk estimates, and reservation details.
- **Reservation Requester:** submits booking information through the campus reservation process.
- **System Analyst:** reviews data quality and model performance.""")
    st.subheader("Functional requirements")
    st.markdown("""1. The system shall validate uploaded reservation CSV files and report missing required columns.
2. The system shall display reservation counts by facility type and observed outcome.
3. The system shall calculate observed Not Completed percentages by user category.
4. The system shall estimate the outcome of a new reservation using the saved midterm Decision Tree pipeline.
5. The system shall provide a review queue and clearly distinguish model predictions from observed outcomes.""")
    st.subheader("Non-functional requirements")
    st.markdown("""1. **Usability:** navigation and results shall be clearly labeled.
2. **Reliability:** invalid uploads shall show helpful error messages; model loading is cached.
3. **Privacy and safety:** use only synthetic or authorized data; never automatically reject reservations based on predictions.""")
    st.subheader("Use case diagram")
    st.image(ROOT / "assets" / "use_case_diagram.png", use_container_width=True)
    st.subheader("Decision workflow")
    st.code("Reservation details available → Validate inputs → Apply saved preprocessing + Decision Tree → Display estimated outcome and probability → Administrator reviews evidence → Human makes final decision", language="text")
    st.caption("The uploaded midterm report's test accuracy was 57.50%; this is a preliminary decision-support model.")

st.divider()
st.caption("Campus Facility Reservation Monitoring · Midterm model reused for decision support")
