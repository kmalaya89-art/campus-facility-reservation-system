import joblib
import pandas as pd
from pathlib import Path

MODEL_PATH = Path(__file__).resolve().parents[1] / "models" / "trained_model.joblib"

def load_model():
    return joblib.load(MODEL_PATH)

def predict_one(model, values):
    features = [
        "Facility_Type", "User_Category", "Reservation_Purpose", "Lead_Time_Days",
        "Reservation_Duration_Hours", "Participants", "Day_of_Week", "Start_Hour"
    ]
    row = pd.DataFrame([{k: values[k] for k in features}], columns=features)
    label = model.predict(row)[0]
    probabilities = model.predict_proba(row)[0]
    classes = list(model.classes_)
    risk = float(probabilities[classes.index("Not Completed")]) if "Not Completed" in classes else None
    return label, risk
