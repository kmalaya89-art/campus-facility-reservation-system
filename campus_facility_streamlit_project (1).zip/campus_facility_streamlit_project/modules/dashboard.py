import pandas as pd

def summarize(df, model):
    predictors = [
        "Facility_Type", "User_Category", "Reservation_Purpose", "Lead_Time_Days",
        "Reservation_Duration_Hours", "Participants", "Day_of_Week", "Start_Hour"
    ]
    valid = df.dropna(subset=["Reservation_Outcome"]).copy()
    X = valid[predictors]
    valid["Predicted_Outcome"] = model.predict(X)
    probabilities = model.predict_proba(X)
    classes = list(model.classes_)
    if "Not Completed" in classes:
        valid["Predicted_Not_Completed_Probability"] = probabilities[:, classes.index("Not Completed")] * 100
    else:
        valid["Predicted_Not_Completed_Probability"] = float("nan")
    return valid
