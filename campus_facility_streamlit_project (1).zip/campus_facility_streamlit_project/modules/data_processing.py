import pandas as pd

REQUIRED_COLUMNS = [
    "Reservation_ID", "Facility_Type", "User_Category", "Reservation_Purpose",
    "Reservation_Date", "Submission_Date", "Lead_Time_Days",
    "Reservation_Duration_Hours", "Participants", "Day_of_Week", "Start_Hour",
    "Usage_Status", "Actual_Attendance", "Cancellation_Days_Before"
]
PREDICTOR_COLUMNS = [
    "Facility_Type", "User_Category", "Reservation_Purpose", "Lead_Time_Days",
    "Reservation_Duration_Hours", "Participants", "Day_of_Week", "Start_Hour"
]

def validate_dataframe(df):
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        return False, f"Missing required columns: {', '.join(missing)}"
    if df.empty:
        return False, "The uploaded dataset has no rows."
    return True, "Dataset schema is valid."

def prepare_dataframe(df):
    df = df.drop_duplicates().reset_index(drop=True).copy()
    for col in ["Facility_Type", "User_Category", "Reservation_Purpose", "Usage_Status"]:
        if col in df.columns:
            df[col] = df[col].astype("string").str.strip()
    df["Facility_Type"] = df["Facility_Type"].replace({"classroom": "Classroom"})
    df["User_Category"] = df["User_Category"].replace({"faculty": "Faculty"})
    df.loc[df["Reservation_Duration_Hours"] <= 0, "Reservation_Duration_Hours"] = float("nan")
    df.loc[(df["Start_Hour"] < 0) | (df["Start_Hour"] > 23), "Start_Hour"] = float("nan")
    df.loc[(df["Participants"] == 0) & (df["Actual_Attendance"] > 0), "Participants"] = float("nan")
    df.loc[df["Lead_Time_Days"] < 0, "Lead_Time_Days"] = float("nan")
    df["Lead_Time_Category"] = pd.cut(
        df["Lead_Time_Days"], [-float("inf"), 2, 7, 14, float("inf")],
        labels=["Last Minute", "Short Lead", "Medium Lead", "Early Booking"]
    )
    df["Reservation_Outcome"] = df["Usage_Status"].map({
        "Used": "Completed", "Cancelled": "Not Completed", "No-Show": "Not Completed"
    })
    df["Attendance_Ratio"] = df["Actual_Attendance"] / df["Participants"].replace(0, float("nan"))
    return df
