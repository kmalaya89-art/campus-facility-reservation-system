import pandas as pd
import plotly.express as px

def outcome_counts(df):
    return df["Reservation_Outcome"].value_counts(dropna=False).rename_axis("Outcome").reset_index(name="Count")

def charts(df):
    chart1 = px.bar(df["Facility_Type"].value_counts().reset_index(),
                    x="Facility_Type", y="count", title="Observed Reservations by Facility Type",
                    labels={"Facility_Type":"Facility Type","count":"Reservations"})
    user = df.groupby("User_Category").agg(
        Total=("Reservation_ID","count"),
        Not_Completed=("Reservation_Outcome", lambda s: (s == "Not Completed").sum())
    ).reset_index()
    user["Not Completed (%)"] = (user["Not_Completed"] / user["Total"] * 100).round(2)
    chart2 = px.bar(user, x="User_Category", y="Not Completed (%)",
                    title="Observed Not-Completed Percentage by User Category")
    lead = df.groupby(["Lead_Time_Category","Reservation_Outcome"], observed=False).size().reset_index(name="Count")
    chart3 = px.bar(lead, x="Lead_Time_Category", y="Count", color="Reservation_Outcome",
                    barmode="stack", title="Observed Outcomes by Lead-Time Category")
    return chart1, chart2, chart3, user
